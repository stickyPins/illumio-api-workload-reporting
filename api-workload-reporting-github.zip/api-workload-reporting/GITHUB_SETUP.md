# Add this project to GitHub

Suggested repository name: `api-workload-reporting`

Suggested description: Python REST API demo that transforms JSON records into simulated workloads, filters Production environments, and exports CSV reports.

Suggested topics: `python`, `rest-api`, `automation`, `csv`, `infrastructure`, `portfolio-project`

## Upload using your browser

1. Extract the ZIP on your computer.
2. Create a new GitHub repository named `api-workload-reporting`. Choose Public if you want employers to view it. Leave automatic README, license, and gitignore initialization off because this package already includes supporting files.
3. Upload the contents of the extracted `api-workload-reporting` folder into the repository root. Upload the files and subfolders, not the ZIP or an extra enclosing folder.
4. Include `.github/workflows/tests.yml` and `.gitignore`; your file browser may hide names beginning with a dot. Use the terminal route below if uploading those files is inconvenient.
5. Commit with the message `Add API workload reporting portfolio project`.
6. Check the Actions tab for the Python tests result. Pin the repository on your profile and add its URL to your resume or portfolio.

## Upload using Git

Create an empty repository first. Then open a terminal in the extracted project folder and run:

```bash
python -m unittest discover -s tests -v
git init
git add .
git commit -m "Add API workload reporting portfolio project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/api-workload-reporting.git
git push -u origin main
```

Replace `YOUR_USERNAME` before running the remote command. Git and GitHub authentication must already be available on your computer. If prompted, use your normal GitHub authentication method.

## Before publishing

- Read the code and README so you can explain the mapping and limitations.
- Confirm the files contain only demonstration data you intend to publish.
- Choose a license if you want to give others permission to reuse the code. No license is included automatically.
- Keep the generated report ignored; the supplied example is tracked under `examples/`.

This package prepares the repository contents; it does not create or publish a GitHub repository for you.
