import csv
import io
from contextlib import redirect_stdout
from pathlib import Path
import tempfile
import os
import unittest
from unittest.mock import patch
import urllib.error

import workload_report as report


class WorkloadReportTests(unittest.TestCase):
    def test_transform_matches_supplied_example(self):
        records = [{"id": n} for n in range(1, 11)]
        result = report.filter_production(report.process_workloads(records))
        example = Path(__file__).resolve().parents[1] / "examples/production_workloads.csv"
        with example.open(newline="") as source:
            self.assertEqual(result, list(csv.DictReader(source)))

    def test_filter_requires_exact_production(self):
        rows = [{"environment": value} for value in
                ("Production", "Development", "Testing", "production")]
        self.assertEqual(report.filter_production(rows), [rows[0]])
        self.assertEqual(report.filter_production([]), [])

    def test_export_empty_still_writes_headers(self):
        previous = Path.cwd()
        with tempfile.TemporaryDirectory() as directory:
            try:
                os.chdir(directory)
                with redirect_stdout(io.StringIO()):
                    report.export_csv([])
                with open("production_workloads.csv", newline="") as source:
                    self.assertEqual(list(csv.reader(source)), [[
                        "hostname", "ip_address", "application", "environment", "status"]])
            finally:
                os.chdir(previous)

    def test_fetch_decodes_json(self):
        response = io.BytesIO(b'[{"id": 1}]')
        response.status = 200
        with patch("workload_report.urllib.request.urlopen", return_value=response) as fetch:
            with redirect_stdout(io.StringIO()):
                self.assertEqual(report.get_workloads(), [{"id": 1}])
        request = fetch.call_args.args[0]
        self.assertEqual(request.full_url, report.API_URL)
        self.assertEqual(fetch.call_args.kwargs["timeout"], 15)

    def test_network_failures_return_empty(self):
        errors = [urllib.error.URLError("offline"), TimeoutError("timeout"),
                  urllib.error.HTTPError(report.API_URL, 503, "Unavailable", {}, None)]
        for error in errors:
            with self.subTest(error=type(error).__name__):
                with patch("workload_report.urllib.request.urlopen", side_effect=error):
                    with redirect_stdout(io.StringIO()):
                        self.assertEqual(report.get_workloads(), [])

    def test_invalid_json_returns_empty(self):
        response = io.BytesIO(b'not json')
        response.status = 200
        with patch("workload_report.urllib.request.urlopen", return_value=response):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(report.get_workloads(), [])


if __name__ == "__main__":
    unittest.main()
