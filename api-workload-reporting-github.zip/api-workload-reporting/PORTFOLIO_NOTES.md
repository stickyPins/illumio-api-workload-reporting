# Portfolio copy and interview preparation

## Project card

**API Workload Reporting | Python Automation**

A Python demonstration of an inventory-reporting workflow: retrieve JSON data from a REST API, transform records into simulated infrastructure workloads, filter by environment, and export a structured CSV report. Uses the standard library and includes offline unit tests and a GitHub Actions test workflow.

## Resume bullet

Developed a Python API reporting demo that transforms JSON records into simulated workload inventory, filters Production environments, and exports CSV reports, with mocked unit tests and automated test configuration for GitHub Actions.

Use this wording only after reviewing the implementation and confirming it accurately describes work you can explain. The supporting tests and documentation were added during portfolio preparation.

## Interview talking points

- Explain the separation between retrieval, transformation, filtering, and export.
- Explain why the standard library was sufficient for a small unauthenticated demo.
- Walk through record ID 4: `server-004`, `10.10.1.4`, CRM, Production, active.
- Point out that both label cycles share the same index, making Production always CRM.
- Discuss schema validation, nonzero failure exit codes, configurable filters, and authenticated inventory as next steps.
- Distinguish the supplied example and mocked tests from an actual live API validation.

## Scope of portfolio preparation

The original Python logic and supplied example CSV are preserved. The source file was renamed to `workload_report.py`; documentation, tests, ignore rules, and a CI workflow were added. No real infrastructure or production-security integration is claimed.
